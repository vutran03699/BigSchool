# BigSchool
Thực hành chiều  thứ 7 Lập Trình WEB

--UP CODE---

git init

git add README.md

git add .

git commit -m "first commit"

git remote add origin https://github.com/vutran03699/BigSchool.git

git push --force origin master

